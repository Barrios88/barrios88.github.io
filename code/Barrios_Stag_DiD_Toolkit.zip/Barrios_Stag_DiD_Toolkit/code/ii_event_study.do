

/*******************************************************************************
							Barrios 2021
					 Staggeringly Problematic
						1) Event Study Code
This code is ment to implement Event Study graphs. The use of these graphs by 
researchers, should help support their arguments that the parallel trends 
assumption holds in their sewtting. A picture is work as thousand words, so this 
should be a key figure to include in DiD papers.

*******************************************************************************/


* set directory 
cd "$base" 

** 1 Open working dataset 
use data/Barrios_working_data.dta, clear

** 2 Create time_to_treat variable 
gen time_to_treat = Year - Year_150_Effective 

* Year_150_Effective - this is the year in which State - s implemented the 150 hour
* Rule.

** 3 Run the standard TWFE estimator - this can be used to compare to the dynamic 
**   effects inlcuded in the graph 
reghdfe log_num_candidates Post_150 , a(Year State_ID Test_Month_ID) vce(cluster State_ID)


/* 4 The production of event study graphs is facilitated by the eventdd command.
	I have set the grapgh to examine 5 exame periods before and 5 periods after 
	using the leads and lags options. This can be changed to suit your particular 
	needs. The accum option basically aggregates any of the pre or post periods past 
	5 in this case to the 5 period estimates.
	
	I provide a basic and fancy graph. To explore other options I refer you to:
	http://ftp.iza.org/dp13524.pdf

*/
/* The eventdd works by estimating a event study usinga regression. The comand 
   allows for multiple estimation procedures:
   ols (ordinary least squares), 
   fe (fixed effects) or 
   hdfe (absorbing multiple levels of fixed effects with the user-written reghdfe command) 
   If no estimation method is specified, ols is used by default.

   In the code I use the hdfe option as you will see below
*/
* Basic Version - set baseline to two period before
eventdd log_num_candidates, timevar(time_to_treat) method(hdfe, absorb(Year State_ID Test_Month_ID) cluster(State_ID )) graph_op( xtitle(Relative time to Treat) graphregion(color(white)) yline( -1.07, lwidth(thick))) lags(5) leads(5) accum baseline(-2) 

* Fancy Version - set baseline to two period before
eventdd log_num_candidates, timevar(time_to_treat) method(hdfe, absorb(Year State_ID Test_Month_ID) cluster(State_ID )) graph_op( xtitle(Relative time to Treat) graphregion(color(white)) yline( -1.07, lwidth(thick))) lags(5) leads(5) accum baseline(-2) ci(rarea) ci_op(fcolor(ltblue%45)) coef_op(msymbol(Oh))

graph export "output/ii_event_study.pdf", replace


