
/*******************************************************************************
							Barrios 2021
					 Staggeringly Problematic
			  4) Callaway and Santanna Estimator
This code is ment the Callaway and Santanna Estimator and produce a 
graph which plots the event study of the cohort ATT.

The Code is implemented in stata but relies on R. Please make sure to install R
as specified in the master do file. Also make sure to install the R packages 
listed in the master do file.

In R the comments are preceeded by a "#".

in order to run the rsource make sure to use the correct first line:

If on a Mac:
rsource, terminator(END_OF_R) rpath("/usr/local/bin/R") roptions(`"--vanilla"')

If on a PC:
rsource , terminator(END_OF_R) rpath(`"c:\r\R-3.5.1\bin\Rterm.exe"') roptions(`"--vanilla"')  

I am using a MAc so initiate with the Mac line

	Note that, when the user downloads a new version of R, the installation
    process creates a new directory, containing the new version of Rterm.exe.
    Therefore, when R is upgraded, the user should either change the system
    default file search path, or change the line of code.
	

For specifics on the attgt implementation of the Callaway and Santanna Estimator
please go to : https://bcallaway11.github.io/did/reference/att_gt.html
*******************************************************************************/
* set directory 
cd "$base" 


* Run the following R codes - make sure to change the path, and the data file location. Also 
* make sure to chnage the location of the output graph.

rsource, terminator(END_OF_R) rpath("/usr/local/bin/R") roptions(`"--vanilla"')

library(tidyverse)
library(fixest)
library(ggthemes)
library(fastDummies)
library(lubridate)
library(pbapply)
library(did)
library(DRDID)
library(here)
library(zoo)
library(tidyverse)
library(lfe)
library(readr)
library(bacondecomp)
library(multcomp)
# Set this path to where the project folder is
path = "/Volumes/LaCie/Dropbox/2.Research Projects/0.Research Proposals/Proposals_2020/Staggared DiD/Replication_Toolkit/"
# Set the dataset you will be using to implement the analysis - it should be a STATA dataset
Barrios_working_data <- haven::read_dta(paste0(path,"data/Barrios_working_data.dta"))

workingdata <- 
  Barrios_working_data %>%
  # dropped all units who are treated in time period 1 as they do not help us recover ATT(g,t)'s.
  filter(Year_150_Effective > 1985) %>%
  filter(!is.na(log_num_candidates)) %>%
  group_by(State_ID, Test_Month_ID) %>%
  mutate(group = group_indices()) %>%
  ungroup()
  
mw.attgt <- att_gt(# the name of the outcome variable
                   yname = "log_num_candidates",
                   # the first year when a particular observation is treated
                   gname = "Year_150_Effective",
                   # the individual (cross-sectional unit) id name
                   idname = "group",
                   # the time periods
                   tname = "Year",
                   xformla = ~1,
                   data = workingdata  ,
                   bstrap = T, 
                   cband = T,
                   # Methods: I use inverse probability weighting but can change,
                   est_method = "ipw", 
				   # Number of anticipation periods
				   anticipation = 0),
                   # also can add notyettreated
                   # the group of units that are never treated
                   control_group = c("nevertreated") 
                   )

# show the average treatment results 
summary(mw.attgt)

# aggregate the group-time average treatment effects
# use 5 periods before and after
mw.dyn <- aggte(mw.attgt, 
                type = "dynamic",
                max_e = 5,
                min_e = -5)
summary(mw.dyn)

event_study_plot <-
  tibble(eventtime = mw.dyn$egt,
       estimate = mw.dyn$att,
       se = mw.dyn$se,
       conf.low = estimate - 1.96*se,
       conf.high = estimate + 1.96*se) %>% 
  mutate(band_groups = case_when(
         eventtime < 0 ~ "Pre 150 Rule",
         eventtime >= 1 ~ "Post 150 Rule",
         eventtime == 0 ~ "")) %>%
  ggplot(aes(x = eventtime, y = estimate, group = band_groups)) + 
  geom_point(color = "red") + 
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0.1) + 
  xlab("Event Time") +
  ylab("Percentage Change in Total Test Takers") +
  geom_hline(yintercept = 0, color = "red") +
  geom_vline(xintercept = -0.5, color = "black") + 
  theme_bw() +
  scale_x_continuous(breaks=c(-5:5)) +
  theme_classic()

# Saving the even study plots - REMEMBER TO CHANGE 
	event_study_plot
	ggsave(paste0(path, "output/Callaway_Event_Plot_JB2.pdf"))

END_OF_R
