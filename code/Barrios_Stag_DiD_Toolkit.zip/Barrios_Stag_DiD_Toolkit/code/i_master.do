/*******************************************************************************
							Barrios 2021
					 Staggeringly Problematic
					 
This code is ment to implement the analysis in Barrios 2021 as well as provide 
researchers with sample codew with which to implement a staggared DiD design in 
there own papers. 

*******************************************************************************/


/*******************************************************************************
							1) STATA Packages Needed 
Before implementing the analysis, researchers are recommended to install the 
following stata packages.					 
*******************************************************************************/
* a. reghdfe
net install ftools, from("https://raw.githubusercontent.com/sergiocorreia/ftools/master/src/") 
ssc install reghdfe  (to install this command)

* b. bacondecomp
ssc install bacondecomp

* c. Abraham and Sun weights
ssc install eventstudyweights

* d. eventdd
ssc install matsort
ssc install eventdd
ssc install boottest

* e. rsource (to run R codes from Stata)
ssc intall rsource 


/*******************************************************************************
							2) Use of R and Installation 
The Callaway_Santanna and Abraham_and_Sun methods are implemented in R. 
Understanding that R is not widely used in accounting I have coded up the two
procedures so that they can be implemented in R via STATA.

In order for my code to work to implement the two methods you will need to 
install R.

A) install R	
	* Windows - Installing R on Windows is simple. First: go to https://cran.r-project.org/.
	*			then simply choose the download R for Windows 
	
	* Mac - Installing R for Mac is similar. Go to https://cran.r-project.org/ and then simply 
	* 		then simply click trhe Download  R for Mac link. 	


B) After you have installed R and the rsource package for stata, you will need to install the 
R packages that will be needed to run the two estimators. I have provided the code you can 
run in state to install them below: 			 
*******************************************************************************/

* Please coment out the one the one that is not your operating system.
* If on Mac:
rsource, terminator(END_OF_R) rpath("/usr/local/bin/R") roptions(`"--vanilla"')

install.packages("tidyverse", repos = "http://cran.us.r-project.org")
install.packages("fixest", repos = "http://cran.us.r-project.org")
install.packages("ggthemes", repos = "http://cran.us.r-project.org")
install.packages("fastDummies", repos = "http://cran.us.r-project.org")
install.packages("lubridate", repos = "http://cran.us.r-project.org")
install.packages("pbapply", repos = "http://cran.us.r-project.org")
install.packages("devtools", repos = "http://cran.us.r-project.org")
devtools::install_github("pedrohcgs/DRDID")
devtools::install_github("bcallaway11/did")
install.packages("here", repos = "http://cran.us.r-project.org")
install.packages("zoo", repos = "http://cran.us.r-project.org")
install.packages("tidyverse", repos = "http://cran.us.r-project.org")
install.packages("lfe", repos = "http://cran.us.r-project.org")
install.packages("readr", repos = "http://cran.us.r-project.org")
install.packages("bacondecomp", repos = "http://cran.us.r-project.org")
install.packages("multcomp", repos = "http://cran.us.r-project.org")
install.packages("haven", repos = "http://cran.us.r-project.org")
install.packages("dplyr", repos = "http://cran.us.r-project.org")

END_OF_R

* If on windows:
rsource, terminator(END_OF_R) rpath(`"c:\r\R-3.5.1\bin\Rterm.exe"') roptions(`"--vanilla"') 
install.packages("tidyverse", repos = "http://cran.us.r-project.org")
install.packages("fixest", repos = "http://cran.us.r-project.org")
install.packages("ggthemes", repos = "http://cran.us.r-project.org")
install.packages("fastDummies", repos = "http://cran.us.r-project.org")
install.packages("lubridate", repos = "http://cran.us.r-project.org")
install.packages("pbapply", repos = "http://cran.us.r-project.org")
install.packages("devtools", repos = "http://cran.us.r-project.org")
devtools::install_github("pedrohcgs/DRDID")
devtools::install_github("bcallaway11/did")
install.packages("here", repos = "http://cran.us.r-project.org")
install.packages("zoo", repos = "http://cran.us.r-project.org")
install.packages("tidyverse", repos = "http://cran.us.r-project.org")
install.packages("lfe", repos = "http://cran.us.r-project.org")
install.packages("readr", repos = "http://cran.us.r-project.org")
install.packages("bacondecomp", repos = "http://cran.us.r-project.org")
install.packages("multcomp", repos = "http://cran.us.r-project.org")
install.packages("haven", repos = "http://cran.us.r-project.org")
install.packages("dplyr", repos = "http://cran.us.r-project.org")

END_OF_R

********************************************************************************


/*******************************************************************************
							3) Setting Working Directory 
To run the scripts it will be useful to define the working directory. This should
be the directory where the data is stored and you whish to have you output stored.

You should create a data folder and an output folder in the working directory so
that the code automatically outputs the figures into the files. These have already 
been created if using my toolkit folder as the working directory.			 
*******************************************************************************/
clear 
set more off 
* 1 Set working directory 
* Set your working directory - this is where you house the code, data and output folders

global base"/Volumes/LaCie/Dropbox/2.Research Projects/0.Research Proposals/Proposals_2020/Staggared DiD/Replication_Toolkit copy/code/Barrios_Stag_DiD_Toolkit"


cd "$base"













