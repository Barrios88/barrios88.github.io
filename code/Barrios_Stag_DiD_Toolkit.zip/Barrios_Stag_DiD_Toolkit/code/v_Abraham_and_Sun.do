/*******************************************************************************
							Barrios 2021
					 Staggeringly Problematic
				   4) Abraham and Sun Estimator
This code is ment to implement Abraham and Sun Estimator and produce a 
graph which plots the event studyestimates of the cohort ATT.

The Code is implemented in stata but relies on R. Please make sure to install R
as specified in the master do file. Also make sure to install the R packages 
listed in the master do file.

In R the comments are preceeded by a "#".

in order to run the rsource make sure to use the correct first line:

If on a Mac:
rsource, terminator(END_OF_R) rpath("/usr/local/bin/R") roptions(`"--vanilla"')

If on a PC:
rsource , terminator(END_OF_R) rpath(`"c:\r\R-3.5.1\bin\Rterm.exe"') roptions(`"--vanilla"') 

I am using a MAc so initiate with the Mac line


For specifics on the attgt implementation of the Callaway and Santanna Estimator
please go to : https://bcallaway11.github.io/did/reference/att_gt.html
*******************************************************************************/
* set directory 
cd "$base" 

* Run the following R codes - make sure to CHANGE the path in the R Code, and the data file location. Also 
* make sure to Change the location of the output graph.

rsource, terminator(END_OF_R) rpath("/usr/local/bin/R") roptions(`"--vanilla"')

library(tidyverse) 
library(fixest)
library(ggthemes)
library(fastDummies)
library(lubridate)
library(pbapply)
library(did)
library(DRDID)
library(here)
library(zoo)
library(tidyverse)
library(lfe)
library(bacondecomp) 
library(haven)
library(readr)
library(dplyr)
library(multcomp)

# Set this path to where the project folder is
path = "/Volumes/LaCie/Dropbox/2.Research Projects/0.Research Proposals/Proposals_2020/Staggared DiD/Replication_Toolkit copy/code/Barrios_Stag_DiD_Toolkit/"
# Set the dataset you will be using to implement the analysis - it should be a STATA dataset
Barrios_working_data <- haven::read_dta(paste0(path,"data/Barrios_working_data.dta"))

workingdata <- 
  Barrios_working_data %>%
  # dropped all units who are treated in time period 1 as they do not help us recover ATT(g,t)'s
  filter(Year_150_Effective  > 1985) 

# Make function that runs satuarated model and weight the different lead lag estimators 
weight_leadlags <- function(data) {
  
  # run regression 
  fit = felm(formula_saturated, data = data, exactDOF = TRUE, cmethod = "reghdfe")
  
  # get coefficients
  coefficients <- 
    fit$coefficients %>%
    as_tibble(rownames = "coef") %>%
    rowwise() %>%
    # get lead and lags 
    mutate(whichlead = word(coef, 1, sep = "__"),
           Year_150_Effective  = as.numeric(str_sub(coef, -4, -1))) %>%
    # remove the post variable
    filter(whichlead %in% covariates_interest) %>%
    # bring in the weights
    left_join(., weights, by = c("whichlead","Year_150_Effective"))  
   
    # get the relevant coefficients and weights into a string to get the linear combination
    get_lincom <- function(ll) {
      # for specific lead lag
      leadlag <- coefficients %>% filter(whichlead == ll)
      # create the linear combination
      F <- paste(paste(leadlag$perc, leadlag$coef, sep = " * ", collapse = " + "), " = 0")
      # conver into a data frame
      broom::tidy(
				  # calculate confidence interval 
				  confint(glht(fit, linfct = F)),
				  conf.int = TRUE) %>% mutate(whichlead = ll)
    }
  # run through all lead lags 
  map_df(covariates_interest, get_lincom) %>%
    # add time variable
    mutate(t = c(-5:-2, 0:5))
}

# Create lead and lags 
# lag -1 is the base 
covariates_sat <- c("lag_5","lag_4","lag_3", "lag_2", "date_0", "lead_1", "lead_2", "lead_3","lead_4","lead_5", "Post")

# Create lead lag dummies - iam using 5 periods before and 5 periods after 
data <- 
  workingdata %>% 
  # drop all units who are treated in time period 1 as they do not help us recover ATT(g,t)'s.
  filter(Year_150_Effective != 1985) %>%
  # variable with relative year
  mutate(relative_year = Year- Year_150_Effective ,
         leadlag = case_when(
				   relative_year < -5 ~ "Pre",
				   relative_year == -5 ~ "lag_5",
				   relative_year == -4 ~ "lag_4",
				   relative_year == -3 ~ "lag_3",
				   relative_year == -2 ~ "lag_2",
				   relative_year == -1 ~ "lag_1",
				   relative_year == 0 ~ "date_0",
				   relative_year == 1 ~ "lead_1",
				   relative_year == 2 ~ "lead_2",
				   relative_year == 3 ~ "lead_3",
				   relative_year == 4 ~ "lead_4",
				   relative_year == 5 ~ "lead_5",
				   relative_year > 5 ~ "Post",
				   is.na(relative_year) ~ "Missing"),
                   leadlag_alt = leadlag) %>% 
  # convert to wider data 
  mutate(val = 1) %>% 
  pivot_wider(names_from = "leadlag_alt", values_from = "val", values_fill = list(val = 0))
 
# Calculate weights by treatment cohort 
weights <- 
  data %>% 
  # convert leadlags to long
  pivot_longer(cols = covariates_sat, 
               names_to = "whichlead",
               values_to = "ll_value") %>% 
  # drop missing values of dep variable 
  filter(ll_value == 1) %>% 
  # count number of obs in each group 
  group_by(Year_150_Effective , whichlead) %>% 
  count %>% 
  # get total count in each leadlag group 
  ungroup() %>% 
  group_by(whichlead) %>% 
  mutate(total = sum(n),
         perc = n / total) %>% 
  dplyr::select(whichlead, Year_150_Effective , perc) %>% 
  ungroup()

# Merge weights 
merge_weights <- weights %>% 
  # get the distinct values of year:leadlag
  dplyr::select(whichlead, Year_150_Effective ) %>% 
  unique() %>% 
  mutate(indic = paste(whichlead, Year_150_Effective , sep = "___"))
  
# Bring in weights to the main dataset 
final_data <- data %>% 
  left_join(merge_weights, 
            by = c("Year_150_Effective", "leadlag" = "whichlead")) %>% 
  # make indicator variables
  mutate(val = 1) %>% 
  # conver to wider format 
  pivot_wider(names_from = indic, values_from = val, values_fill = list(val = 0))

# Get names of lead/lags 
leadlags <- unique(merge_weights$indic)

# Create the forumla for regressions 
covariates_saturated <- paste(leadlags, collapse = "+")
formula_saturated <- as.formula(paste("log_num_candidates ~ ", covariates_saturated , 
                           "| State_ID + Year + Test_Month_ID| 0 | State_ID"))

# A list of dummies used in the plot 
covariates_interest <- c("lag_5","lag_4","lag_3", "lag_2", "date_0", "lead_1", "lead_2", "lead_3","lead_4","lead_5")
 
# Run regressions and prepare to plot the event study 
plot <- final_data %>% 
  # fit the model
  do(fit = weight_leadlags(.)) %>% 
  unnest(fit) %>% 
  # select estimates and confidence interval 
  dplyr::select(t, estimate, conf.low, conf.high) %>% 
  # add t = -1
  bind_rows(tibble(t = -1, estimate = 0, 
				   conf.low = 0, conf.high = 0)) %>% 
  # plot
  ggplot(aes(x = t, y = estimate)) + 
  geom_point(color = "red") + 
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0.1) + 
  geom_hline(yintercept = 0, color = "red") +
  geom_vline(xintercept = -0.5, color = "black") + 
  scale_x_continuous(breaks = -5:5) + 
  #labeling the axises 
  ylab("Percentage Change in Total Test Takers") +
  xlab("Event Time") +
  theme_classic()
 
ggsave(paste0(path, "output/Abraham_Sun_Event_Plot.pdf"))

END_OF_R
