

/*******************************************************************************
							Barrios 2021
					 Staggeringly Problematic
			  5) Stacked regressions procedure - Cengiz et al.
This code implements the stacked regression procedure used in Cengiz et al and 
produce a graph which plots an eventy study graph of the estimate.

Only units that are in the never treated groups and not treated within the 
sample window are allowed to be used as controls in each cohort dataset. The code
can be altered to allow late treated groups to also be used. 
*******************************************************************************/
* Set working directory
cd "$base/data"

** 1. Create working dataset -  stacked data 
use Barrios_working_data.dta, clear

* Generate a dummy for never treated and treatment groups
egen max_treat= max(Post_150), by(State_ID)
gen never_treated = (max_treat == 0)

* drop all units who are treated in time period 1 as they do not help us recover ATT(g,t)'s.
keep if Year_150_Effective >= 1985

* get a list of State_IDid for never treated states
levelsof Year_150_Effective if never_treated == 0 ,local(slist)

save temp/3_stacking_raw, replace 


* Create the various sub samples 
use  temp/3_stacking_raw, clear 

levelsof Year_150_Effective if never_treated == 0 ,local(slist)

* loop over each treated states and keep clean control states to create
* a seperate datasets for each cohort of treated states
foreach var of local slist  {
	display `var'
	use  temp/3_stacking_raw, clear 
	gen group_id = `var'
	
	* keep the treated State_ID and never treated states 
	keep if (Year_150_Effective == `var' | never_treated == 1)
	
	* get the effective Yearfor the treated State_ID
	gen id_year_temp = Year_150_Effective if Year_150_Effective == `var' 
	egen id_Year = max(id_year_temp)
	
	* keep 5 years pre-period and 5 years post-period
	keep if Year <= (id_Year+ 5) 
	keep if Year >= (id_Year- 5)

	save temp/3_stacking_`var', replace
}

* Append all the datasets into master dataset to run analysis
clear
foreach var of local slist  {
	display `var'
	append using temp/3_stacking_`var' 
}	
sort group_id never_treated State_ID Year

save temp/stacking_workingdata, replace 


** 2. Create time_to_treat variable and run even study graph 

* use the stacking data to calculate an average effect 
use temp/stacking_workingdata, clear

* generate standarized event-time variable giving time until passage of event for each state
gen time_to_treat = Year - Year_150_Effective

** 3. Run the event study and plot
eventdd log_num_candidates, timevar(time_to_treat) method(hdfe,absorb(State_ID#group_id  group_id#Year ) vce(cluster State_ID#group_id ) )  graph_op( graphregion(color(white)) ytitle("Percentage Change in Total Test Takers") xtitle("Event Time") ) baseline(-2) lags(5) leads(5) accum  

cd "$base/"
graph export "output/vi_stacked_regression_approach.pdf", replace

