
/*******************************************************************************
							Barrios 2021
					 Staggeringly Problematic
			  3) Goodman-Bacon Decomposition graph
This code is ment to implement the Goodman Bacon decomposition and produce a 
graph which plots the individual 2x2 estimates to their weighst as in the paper.

*******************************************************************************/

* Get  

cd "$base"

* Open working dataset 
use data/Barrios_working_data.dta, clear
xtset 
egen Cal_Month_id=group(Test_Month_ID)

* Run Bacon Decomposition 
bacondecomp log_num_candidates Post_150 Cal_Month_id , stub(Bacon1_)  robust 

* Export PDF of the Graph
graph export "output/iii_goodman_bacon_decomp.pdf", replace
* Outputting to excel the summary of timing group comparisons by group (aggregate effect and weight)

putexcel set output/Bacon_Results.xlsx, sheet(Summary) replace
putexcel A1= "Comparisons" , border(bottom)
putexcel B1 = "Coef." ,  border(bottom)
putexcel C1 = "TotalWeight" , border(bottom)
matrix b = e(sumdd)
putexcel A2 = matrix(b), rownames nformat(number_d2)

* you can then save the betas and weighst for the various individual 2x2 comparisons to analyze
putexcel set output/Bacon_Results.xlsx, sheet(Individual􏰃) modify
putexcel A1= "Comparisons" , border(bottom)
putexcel B1 = "Coef." ,  border(bottom)
putexcel C1 = "Weights" ,  border(bottom)
matrix c = e(dd)'
putexcel A2 = matrix(c), rownames nformat(number_d2)
matrix d=e(wt)'
putexcel C2 = matrix(d),  overwr 



